package com.example.bradyprincipe.controlganadero;

import com.journeyapps.barcodescanner.CaptureActivity;

/**
 * Created by Brady Principe on 08/05/2016.
 */

public class CaptureActivityAnyOrientation extends CaptureActivity {
}
